﻿document.addEventListener("DOMContentLoaded", function () {
    const cells = document.querySelectorAll(".cell");
    const player1Score = document.getElementById("player1-score");
    const player2Score = document.getElementById("player2-score");
    const drawScore = document.getElementById("draw-score");
    const gameOverText = document.getElementById("game-over-text");
    const resetButton = document.getElementById("reset-button");

    let board = ["", "", "", "", "", "", "", "", ""];
    let currentPlayer = "X";
    let gameOver = false;

    let player1Wins = 0;
    let player2Wins = 0;
    let draws = 0;

    const xColor = "#E96079";
    const oColor = "#4BB0E4";
    const messageColor = "#FFFFFF"; 

    function updateScores() {
        player1Score.innerText = player1Wins;
        drawScore.innerText = draws;
        player2Score.innerText = player2Wins;
    }

    function checkWinner() {
        const winningCombinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ];
        for (let combination of winningCombinations) {
            const [a, b, c] = combination;
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                return board[a];
            }
        }
        return board.includes("") ? null : "Draw";
    }

    function handleCellClick(event) {
        const index = event.target.getAttribute("data-index");

        if (board[index] || gameOver) {
            return;
        }

        board[index] = currentPlayer;
        event.target.innerText = currentPlayer;
        event.target.style.color = currentPlayer === "X" ? xColor : oColor;

        const winner = checkWinner();
        if (winner) {
            gameOver = true;
            gameOverText.style.color = messageColor;
            if (winner === "Draw") {
                draws++;
                gameOverText.innerText = "It's a Draw!";
            } else {
                if (winner === "X") {
                    player1Wins++;
                } else {
                    player2Wins++;
                }
                gameOverText.innerText = `${winner} Wins!`;
            }
            updateScores();

            setTimeout(resetBoardOnly, 2000);
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X";
            if (currentPlayer === "O") {
                setTimeout(aiMove, 1000);
            }
        }
    }

    function aiMove() {
        let availableMoves = board.map((cell, index) => cell === "" ? index : null).filter(index => index !== null);
        if (availableMoves.length === 0) return;

        const randomMove = availableMoves[Math.floor(Math.random() * availableMoves.length)];
        board[randomMove] = "O";
        cells[randomMove].innerText = "O";
        cells[randomMove].style.color = oColor;

        const winner = checkWinner();
        if (winner) {
            gameOver = true;
            gameOverText.style.color = messageColor; 
            if (winner === "Draw") {
                draws++;
                gameOverText.innerText = "It's a Draw!";
            } else {
                player2Wins++;
                gameOverText.innerText = `${winner} Wins!`;
            }
            updateScores();

            setTimeout(resetBoardOnly, 2000);
        } else {
            currentPlayer = "X";
        }
    }

    function resetBoardOnly() {
        board = ["", "", "", "", "", "", "", "", ""];
        gameOver = false;
        currentPlayer = "X";
        document.querySelectorAll(".cell").forEach(cell => {
            cell.innerText = "";
            cell.style.color = ""; 
        });
        gameOverText.innerText = "";
        gameOverText.style.color = "";
    }

    function resetGame() {
        connection.invoke("ResetGame").catch(function (err) {
            return console.error(err.toString());
        });
    }

    cells.forEach(cell => {
        cell.addEventListener("click", handleCellClick);
    });

    resetButton.addEventListener("click", resetGame);
});
