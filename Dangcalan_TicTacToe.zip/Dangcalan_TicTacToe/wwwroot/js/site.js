﻿document.addEventListener("DOMContentLoaded", function () {
    const connection = new signalR.HubConnectionBuilder()
        .withUrl("/gameHub")
        .configureLogging(signalR.LogLevel.Information)
        .build();

    connection.start()
        .then(() => console.log("SignalR Connected!"))
        .catch(err => console.error("SignalR Connection Error:", err));

    const cells = document.querySelectorAll(".cell");
    let board = ["", "", "", "", "", "", "", "", ""];
    let gameActive = true;
    let isMultiplayer = false;
    let currentPlayer = "X";

    const player1ScoreElement = document.getElementById("player1-score");
    const player2ScoreElement = document.getElementById("player2-score");
    const drawScoreElement = document.getElementById("draw-score");

    function resetLocalGame() {
        board = ["", "", "", "", "", "", "", "", ""];
        cells.forEach(cell => {
            cell.innerText = "";
            cell.style.fontSize = "40px";
        });
        gameActive = true;
        currentPlayer = "X";
        document.getElementById("turn-indicator").innerText = "Player X's Turn";
        document.getElementById("game-over-text").innerText = "";
    }

    function handleClick(event) {
        if (!gameActive) return;
        const index = event.target.dataset.index;
        if (board[index] !== "") return;

        if (isMultiplayer) {
            connection.invoke("MakeMove", parseInt(index), currentPlayer)
                .catch(err => console.error("SignalR Error:", err));
        } else {
            board[index] = currentPlayer;
            event.target.innerText = currentPlayer;
            event.target.style.fontSize = "40px";
            event.target.classList.add(currentPlayer.toLowerCase());

            const winner = checkWinner();
            if (winner) {
                gameActive = false;
                document.getElementById("game-over-text").innerText = winner === "Draw" ? "It's a Draw!" : `${winner} Wins!`;

                if (winner === "X") player1ScoreElement.innerText = parseInt(player1ScoreElement.innerText) + 1;
                else if (winner === "O") player2ScoreElement.innerText = parseInt(player2ScoreElement.innerText) + 1;
                else if (winner === "Draw") drawScoreElement.innerText = parseInt(drawScoreElement.innerText) + 1;

                setTimeout(resetLocalGame, 2000);
            } else {
                currentPlayer = currentPlayer === "X" ? "O" : "X";
                document.getElementById("turn-indicator").innerText = `Player ${currentPlayer}'s Turn`;
            }
        }
    }

    function checkWinner() {
        const winningCombinations = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6]
        ];
        for (const condition of winningCombinations) {
            const [a, b, c] = condition;
            if (board[a] && board[a] === board[b] && board[a] === board[c]) {
                return board[a];
            }
        }
        return board.includes("") ? null : "Draw";
    }

    connection.on("ReceiveMove", (index, player, color) => {
        if (board[index] !== "") return;

        board[index] = player;
        const cell = document.querySelector(`.cell[data-index='${index}']`);
        if (cell) {
            cell.innerText = player;
            cell.style.color = color; 
            cell.style.fontSize = "40px";
        }

        const winner = checkWinner();
        if (winner) {
            gameActive = false;
            document.getElementById("game-over-text").innerText = winner === "Draw" ? "It's a Draw!" : `${winner} Wins!`;

            if (winner === "X") player1ScoreElement.innerText = parseInt(player1ScoreElement.innerText) + 1;
            else if (winner === "O") player2ScoreElement.innerText = parseInt(player2ScoreElement.innerText) + 1;
            else if (winner === "Draw") drawScoreElement.innerText = parseInt(drawScoreElement.innerText) + 1;

            setTimeout(resetLocalGame, 2000);
        } else {
            currentPlayer = player === "X" ? "O" : "X";
        }
    });


    connection.on("GameOver", (winner, playerXWins, playerOWins, draws) => {
        gameActive = false;
        const gameOverText = document.getElementById("game-over-text");
        gameOverText.style.color = "#FFFFFF"; 

        if (winner === "Draw") {
            gameOverText.innerText = "It's a Draw!";
        } else {
            gameOverText.innerText = `${winner} Wins!`;
        }

        player1ScoreElement.innerText = playerXWins;
        player2ScoreElement.innerText = playerOWins;
        drawScoreElement.innerText = draws;

        setTimeout(resetLocalGame, 2000);
    });


    connection.on("GameReset", () => {
        player1ScoreElement.innerText = "0";
        player2ScoreElement.innerText = "0";
        drawScoreElement.innerText = "0";
        resetLocalGame();
    });

    const resetButton = document.getElementById("reset-button");
    if (resetButton) {
        resetButton.addEventListener("click", () => {
            if (isMultiplayer) {
                connection.invoke("ResetGame").catch(err => console.error("SignalR Error:", err));
            } else {
                resetLocalGame();
            }
        });
    }

    cells.forEach(cell => cell.addEventListener("click", handleClick));
});