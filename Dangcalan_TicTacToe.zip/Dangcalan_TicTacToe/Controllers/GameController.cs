﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Dangcalan_TicTacToe.Controllers
{
    [Route("api/game")]
    [ApiController]
    public class GameController : ControllerBase
    {
        private static string[] board = new string[9] { "", "", "", "", "", "", "", "", "" };

        [HttpGet("GetGameState")]
        public IActionResult GetGameState()
        {
            return Ok(board); // Returns the current board state as JSON
        }

        [HttpPost("UpdateGameState")]
        public IActionResult UpdateGameState([FromBody] Dictionary<string, string> move)
        {
            if (move.ContainsKey("index") && move.ContainsKey("player"))
            {
                int index = int.Parse(move["index"]);
                string player = move["player"];

                if (index >= 0 && index < 9 && string.IsNullOrEmpty(board[index]))
                {
                    board[index] = player;
                    return Ok(new { success = true, board });
                }
            }
            return BadRequest(new { success = false, message = "Invalid move" });
        }

        [HttpPost("ResetGame")]
        public IActionResult ResetGame()
        {
            board = new string[9] { "", "", "", "", "", "", "", "", "" };
            return Ok(new { success = true, message = "Game reset successfully" });
        }
    }
}
