using Dangcalan_TicTacToe.Hubs;

namespace Dangcalan_TicTacToe
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowSpecificOrigins",
                    policy =>
                    {
                        policy.WithOrigins("http://localhost:5090", "https://localhost:7161") // Match the backend ports
                              .AllowCredentials()
                              .AllowAnyHeader()
                              .AllowAnyMethod();
                    });
            });

            builder.Services.AddControllersWithViews();
            builder.Services.AddSignalR();

            var app = builder.Build();

            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseCors("AllowSpecificOrigins");

            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthorization();

            app.MapHub<Dangcalan_TicTacToe.Hubs.GameHub>("/gameHub");
            app.MapHub<Dangcalan_TicTacToe.Hubs.AI_GameHub>("/aigameHub");

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
