﻿using Microsoft.AspNetCore.SignalR;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace Dangcalan_TicTacToe.Hubs
{
    public class GameHub : Hub
    {
        private static ConcurrentDictionary<string, string[]> gameBoards = new();
        private static ConcurrentDictionary<string, string> currentPlayers = new();

        public async Task JoinGame(string gameId)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, gameId);

            if (!gameBoards.ContainsKey(gameId))
            {
                gameBoards[gameId] = new string[9];
                currentPlayers[gameId] = "X"; // X always starts
            }

            await Clients.Group(gameId).SendAsync("GameStateUpdated", gameBoards[gameId]);
        }


        public async Task MakeMove(string gameId, int index)
        {
            if (!gameBoards.ContainsKey(gameId)) return;
            var board = gameBoards[gameId];

            if (index < 0 || index >= 9 || !string.IsNullOrEmpty(board[index])) return;

            string player = currentPlayers[gameId];
            board[index] = player;

            await Clients.Group(gameId).SendAsync("ReceiveMove", index, player);

            string winner = CheckWinner(board);
            if (winner != null)
            {
                await Clients.Group(gameId).SendAsync("GameOver", winner);
                await ResetGame(gameId);  // ✅ Ensure ResetGame is awaited
            }
            else
            {
                currentPlayers[gameId] = (player == "X") ? "O" : "X";
            }
        }


        private string CheckWinner(string[] board)
        {
            int[][] winningCombinations = new int[][]
            {
                new[] {0, 1, 2}, new[] {3, 4, 5}, new[] {6, 7, 8}, // Rows
                new[] {0, 3, 6}, new[] {1, 4, 7}, new[] {2, 5, 8}, // Columns
                new[] {0, 4, 8}, new[] {2, 4, 6}  // Diagonals
            };

            foreach (var combo in winningCombinations)
            {
                if (!string.IsNullOrEmpty(board[combo[0]]) &&
                    board[combo[0]] == board[combo[1]] &&
                    board[combo[0]] == board[combo[2]])
                {
                    return board[combo[0]];
                }
            }

            return board.Contains("") ? "" : "Draw";
        }

        public async Task ResetGame(string gameId)
        {
            if (gameBoards.ContainsKey(gameId))
            {
                gameBoards[gameId] = new string[] { "", "", "", "", "", "", "", "", "" };
                currentPlayers[gameId] = "X";
                await Clients.Group(gameId).SendAsync("GameReset");
            }
        }

    }
}
