﻿using Microsoft.AspNetCore.SignalR;
using System.Linq;
using System.Threading.Tasks;

namespace Dangcalan_TicTacToe.Hubs
{
    public class AI_GameHub : Hub
    {
        private static string[] board = { "", "", "", "", "", "", "", "", "" };
        private static string currentPlayer = "X";
        private static bool gameInProgress = true;
        private static readonly string aiPlayer = "O";
        private static readonly string humanPlayer = "X";
        private static int player1Wins = 0;
        private static int player2Wins = 0;
        private static int draws = 0;

        private static readonly string xColor = "#E96079"; 
        private static readonly string oColor = "#4BB0E4"; 
        private static readonly string messageColor = "#FFFFFF"; 

        public async Task MakeMove(int index, string player)
        {
            if (gameInProgress && board[index] == "" && player == currentPlayer)
            {
                board[index] = player;
                string color = player == "X" ? xColor : oColor;
                currentPlayer = aiPlayer;

                await Clients.All.SendAsync("ReceiveMove", index, player, color);

                string winner = CheckWinner();
                if (winner != "Ongoing")
                {
                    await HandleGameOver(winner);
                }
                else
                {
                    await AI_Move();
                }
            }
        }

        private async Task AI_Move()
        {
            int bestMove = Minimax(board, aiPlayer, int.MinValue, int.MaxValue);
            board[bestMove] = aiPlayer;
            string color = oColor;
            currentPlayer = humanPlayer;

            await Clients.All.SendAsync("ReceiveMove", bestMove, aiPlayer, color);

            string winner = CheckWinner();
            if (winner != "Ongoing")
            {
                await HandleGameOver(winner);
            }
        }

        private async Task HandleGameOver(string winner)
        {
            gameInProgress = false;

            if (winner == "X") player1Wins++;
            if (winner == "O") player2Wins++;
            if (winner == "Draw") draws++;

            await Clients.All.SendAsync("GameOver", winner, player1Wins, player2Wins, draws, messageColor);
            await Clients.All.SendAsync("ProceedToNextLevel");
        }

        private string CheckWinner()
        {
            const string draw = "Draw";

            var winningCombinations = new[]
            {
                new[] { 0, 1, 2 }, new[] { 3, 4, 5 }, new[] { 6, 7, 8 },
                new[] { 0, 3, 6 }, new[] { 1, 4, 7 }, new[] { 2, 5, 8 },
                new[] { 0, 4, 8 }, new[] { 2, 4, 6 }
            };

            foreach (var combination in winningCombinations)
            {
                var (a, b, c) = (combination[0], combination[1], combination[2]);
                if (board[a] == board[b] && board[a] == board[c] && !string.IsNullOrEmpty(board[a]))
                {
                    return board[a];
                }
            }

            return board.Contains("") ? "Ongoing" : draw;
        }

        private int[] GetAvailableMoves(string[] board)
        {
            return board.Select((value, index) => new { value, index })
                        .Where(x => string.IsNullOrEmpty(x.value))
                        .Select(x => x.index)
                        .ToArray();
        }

        private int Minimax(string[] board, string player, int alpha, int beta)
        {
            var availableMoves = GetAvailableMoves(board);

            string winner = CheckWinner();
            if (winner == aiPlayer)
                return 1;
            if (winner == humanPlayer)
                return -1;
            if (!availableMoves.Any())
                return 0;

            int bestMove = -1;
            int bestScore = (player == aiPlayer) ? int.MinValue : int.MaxValue;

            foreach (var move in availableMoves)
            {
                board[move] = player;

                int score = Minimax(board, player == aiPlayer ? humanPlayer : aiPlayer, alpha, beta);

                board[move] = "";

                if (player == aiPlayer)
                {
                    if (score > bestScore)
                    {
                        bestScore = score;
                        bestMove = move;
                    }
                    alpha = Math.Max(alpha, bestScore);
                }
                else
                {
                    if (score < bestScore)
                    {
                        bestScore = score;
                        bestMove = move;
                    }
                    beta = Math.Min(beta, bestScore);
                }

                if (beta <= alpha)
                    break;
            }

            if (bestMove == -1) bestMove = PrioritizeBestMove(board);

            return bestMove;
        }

        private int PrioritizeBestMove(string[] board)
        {
            if (board[4] == "")
            {
                return 4;
            }

            int[] corners = new int[] { 0, 2, 6, 8 };
            foreach (var corner in corners)
            {
                if (board[corner] == "")
                {
                    return corner;
                }
            }

            return board.Select((value, index) => new { value, index })
                        .FirstOrDefault(x => string.IsNullOrEmpty(x.value))?.index ?? -1;
        }

        public async Task ResetGame()
        {
            board = new string[] { "", "", "", "", "", "", "", "", "" };
            currentPlayer = humanPlayer;
            gameInProgress = true;

            player1Wins = 0;
            player2Wins = 0;
            draws = 0;

            await Clients.All.SendAsync("GameReset");
            await Clients.All.SendAsync("ScoresReset", player1Wins, player2Wins, draws);
            await Clients.All.SendAsync("RedirectToAI");
        }

        public async Task ProceedToNextLevel()
        {
            board = new string[] { "", "", "", "", "", "", "", "", "" };
            currentPlayer = humanPlayer;
            gameInProgress = true;

            await Clients.All.SendAsync("NextRound");
            await Task.Delay(500);
        }
    }
}
